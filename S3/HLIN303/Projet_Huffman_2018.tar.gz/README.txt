Projet Huffman 2018 :

Etudiants :
Canta Thomas
Reiter Maxime
Desgenetez Charles

Compilation : make

Toute les informations sont disponibles pour faire fonctionner 
notre programme en utilisant la commande : ./huf -h ou -help

/!\ NE PAS UTILISER LES CARACTERES DE LA TABLE ASCII ETENDUE /!\
Cela peut marcher mais je ne vous garantie rien !