#ifndef _DECOMPRESS_H
#define _DECOMPRESS_H

/*
 * Fonction : decompress;
 * @param : argv[]: tableau de caractere;
 * @description : Permet de décompressé un fichier compréssé par la même méthode;
 *
*/
void decompress(char* argv[]);

#endif