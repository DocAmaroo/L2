#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
//#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "progListeSC.h"
#include "fichierTP5.h"

using namespace std;


Dico creerDico(bool b, Dico G, Dico D){
  /* Res : renvoie une Dico dont la racine vaut e, le sag G et le sad D   */
  Dico A = new NoeudSC;
  A->info=b;  A->sag=G;  A->sad=D;
  return A;}

void codageABdot(ofstream& fichier, Dico A){
  if (A != NULL){ 
    fichier << (long) A << " [label=\""  << (A->info?"true":"false") << "\" ] ;\n";
    if (A->sag != NULL) {
      fichier << (long)A << " -> " << (long)(A->sag) <<  " [color=\"red\",label=\"0\" ] ;\n";
      codageABdot(fichier,A->sag);} 
    if (A->sad != NULL) {
      fichier << (long)A << " -> " << (long)(A->sad) << " [color=\"blue\",label=\"1\" ] ;\n";
      codageABdot(fichier,A->sad);}
  }
  return;}


void dessinerAB(Dico A, const char * nomFic, string titre){
  ofstream f(nomFic);
  if (!f.is_open()){
   cout << "Impossible d'ouvrir le fichier en �criture !" << endl;
  }
  else {
    f<< "digraph G {   label = \""<< titre << "\" \n";
    f<< "graph [ fontname=""fixed"", fontsize = 20];";
    f<< "node [ fontname=""fixed"", fontsize = 20];";
    f<< "edge [ fontname=""fixed"", fontsize = 20];";
    codageABdot(f,A);
    f << "\n }\n" ;
    f.close();}
  return;}


/* A COMPLETER */
int nbMots(Dico A){
  // renvoie le nombre de mots du dictionnaire A 
  /* A MODIFIER  */

  return 0;
}


bool appMot(Dico D, ListeSC L){
  // teste si le mot L appartient au dictionnaire D
  /* A MODIFIER  */

  return false;
}

void ajouterMot(Dico &A,ListeSC L){
  // ajoute le mot L au dictionnaire A
  /* A MODIFIER  */

}

void supprimerMot(Dico &A,ListeSC L){
  // supprime le mot L du dictionnaire A
  /* A MODIFIER  */
}

int lgMin(Dico A){
  // A un un arbre dictionnaire contenant au moins un mot
  // renvoie la longueur du plus petit mot du dictionnaire A
  assert(nbMots(A)>0);
  /* A MODIFIER  */

  return 0;
}

bool contientPrefixe(Dico A){
  // Renvoie true si le dictionnaire contient au moins un mot et l'un de ses pr�fixes, renvoie false sinon
  /* A MODIFIER  */

  return false;
}

ListeSC motMin(Dico A){
  // A un Dictionnaire non vide
  // Renvoie le plus petit mot du dictionnaire dans l'ordre lexicographique (du dictionnaire)
  assert(nbMots(A)>0);
  /* A MODIFIER  */
  return NULL;
}

